var total = 0;
//set event listener: user types number, hits enter then fire function called enter
document.getElementById('entry').onsubmit = enter;

function enter(e) {
	e.preventDefault();//prevent default refreshing
  var num = document.getElementById('newEntry').value;//declare num variable and assign value of user input
  add(num, total);//fire addTwo function when enter is hit to add total to variable num 
  currency = currencyFormat(num);
  document.getElementById('total').innerHTML = currency;
 


}

function currencyFormat(number) {
  var currency = parseFloat(number);
  currency = currency.toFixed(2);
  currency = '$' + currency;
  return currency;//display $value.00
}

function add(x,y){
	return x+y;
}



//create function to format num variable 