
$(document).ready(function(){
	//set up variable that counts matches
var clickCount = 0;
	//set up empty array, push clicked(class=selected) items into array, then compare objects in array by index
var selectedArray=["",""];

	//click on card, set event listener for this method
$(".card").on("click", function(){
	clickCount = clickCount + 1;
	console.log(clickCount);
	//this becomes img with .card, .selected, and .king/.queen 
	$(this).addClass("selected");
	$(this).attr("src", randomC = getCard());
});

function getCard(){
	var randomNumber=Math.random();
	if(randomNumber<.5){
		randomC="../images/King.png";
		$("img").addClass("king");
		
	}
	else{
		randomC="../images/Queen.png";
		$("img").addClass("queen");
	
	}
	return randomC;
};
	//call function that changes that image, figure out which card got flipped, assign class selected that is unclickable
	//create event listener for another clicked card, which runs(changes images, figures out what card was flipped, pushes that card into array,assign class selected that is unclickable)
	//determine if there is a match 

	//define variable for counter to track card clicks, set count = 0(counter++)
	//conditionals if first two don't match, on third click flip last two cards over, on fourth click
	
	//(togggle class selected should )
	 //ELSE()
	//compare items based on indecies

	
	//if index 1 and index 0 are equal (var[0]=var[1])A MATCH!COMPARISON, go back to event listener, run comparisons, matchcounter
	//if two matches, set up alert that reveals click count to player

	//ELSE(), go back to event listener for card click
	//alert how many turns it took to match 

	//array for cards
	//create click elements for start and reset
	
//understand now that you have gotten 

});
//a turn is two clicks, divide counter by two
//when array length equals two, trigger comparison 